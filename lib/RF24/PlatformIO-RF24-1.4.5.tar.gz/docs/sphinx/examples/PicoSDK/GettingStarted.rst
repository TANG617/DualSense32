gettingStarted
==================

.. seealso::
    `defaultPins.h <default_pins.html>`_

.. literalinclude:: ../../../../examples_pico/gettingStarted.cpp
    :caption: examples_pico/gettingStarted.cpp
    :linenos:
